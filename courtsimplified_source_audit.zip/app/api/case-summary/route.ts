import { NextResponse } from "next/server";

type CourtPath = "family" | "small-claims" | "civil" | "not-sure";

type EmotionalTone =
  | "standard"
  | "supportive"
  | "urgent"
  | "simplified";

type ComplexityLevel =
  | "simple"
  | "moderate"
  | "complex"
  | "high-risk"
  | "not-sure";

type CourtSimplifiedAnalysis = {
  summary: string;
  plainLanguageSummary: string;
  nextStepMessage: string;

  courtPath: CourtPath;
  province: string;
  caseType: string;
  currentStage: string;
  userRole: string;

  detectedLegalPaths: string[];
  factualThemes: string[];
  complexityLevel: ComplexityLevel;

  completedForms: string[];
  receivedForms: string[];
  requiredNextForms: string[];
  laterForms: string[];
  notNeededNow: string[];

  missingInformation: string[];
  evidenceMentioned: string[];
  evidenceNeeded: string[];

  legalIssues: string[];
  timelineAnalysis: string[];
  proceduralStageReasoning: string[];

  risks: string[];
  urgencyFlags: string[];
  emotionalTone: EmotionalTone;

  contradictions: string[];

  evidenceStrengths: string[];
  evidenceWeaknesses: string[];
  missingEvidence: string[];

  deadlineRisks: string[];
  serviceRisks: string[];
  limitationRisks: string[];

  opposingArguments: string[];
  courtConcerns: string[];

  recommendedQuestions: string[];
  caseStrategy: string[];
  casePackageItems: string[];

  nextSteps: string[];
};

function cleanList(items: unknown): string[] {
  if (!Array.isArray(items)) return [];

  return Array.from(
    new Set(
      items
        .map((item) => String(item || "").trim())
        .filter(Boolean)
    )
  );
}

function safeString(value: unknown, fallback = "") {
  const text = String(value || "").trim();
  return text || fallback;
}

function normalizeCourtPath(value: unknown): CourtPath {
  if (
    value === "family" ||
    value === "small-claims" ||
    value === "civil" ||
    value === "not-sure"
  ) {
    return value;
  }

  return "not-sure";
}

function normalizeTone(value: unknown): EmotionalTone {
  if (
    value === "standard" ||
    value === "supportive" ||
    value === "urgent" ||
    value === "simplified"
  ) {
    return value;
  }

  return "supportive";
}

function normalizeComplexity(value: unknown): ComplexityLevel {
  if (
    value === "simple" ||
    value === "moderate" ||
    value === "complex" ||
    value === "high-risk" ||
    value === "not-sure"
  ) {
    return value;
  }

  return "not-sure";
}

function fallbackAnalysis(message: string): CourtSimplifiedAnalysis {
  return {
    summary: message,
    plainLanguageSummary: message,
    nextStepMessage:
      "That’s okay — we’ll guide you through this step by step.",

    courtPath: "not-sure",
    province: "Ontario",
    caseType: "Unknown",
    currentStage: "Unknown",
    userRole: "not-sure",

    detectedLegalPaths: [],
    factualThemes: [],
    complexityLevel: "not-sure",

    completedForms: [],
    receivedForms: [],
    requiredNextForms: [],
    laterForms: [],
    notNeededNow: [],

    missingInformation: [],
    evidenceMentioned: [],
    evidenceNeeded: [],

    legalIssues: [],
    timelineAnalysis: [],
    proceduralStageReasoning: [],

    risks: [],
    urgencyFlags: [],
    emotionalTone: "supportive",

    contradictions: [],

    evidenceStrengths: [],
    evidenceWeaknesses: [],
    missingEvidence: [],

    deadlineRisks: [],
    serviceRisks: [],
    limitationRisks: [],

    opposingArguments: [],
    courtConcerns: [],

    recommendedQuestions: [],
    caseStrategy: [],
    casePackageItems: [],

    nextSteps: [],
  };
}

function sanitizeAnalysis(
  parsed: Partial<CourtSimplifiedAnalysis>
): CourtSimplifiedAnalysis {
  return {
    summary: safeString(parsed.summary),
    plainLanguageSummary: safeString(
      parsed.plainLanguageSummary,
      safeString(parsed.summary)
    ),

    nextStepMessage: safeString(
      parsed.nextStepMessage,
      "That’s okay — we’ll guide you through this step by step."
    ),

    courtPath: normalizeCourtPath(parsed.courtPath),

    province: safeString(parsed.province, "Ontario"),

    caseType: safeString(parsed.caseType, "Unknown"),

    currentStage: safeString(parsed.currentStage, "Unknown"),

    userRole: safeString(parsed.userRole, "not-sure"),

    detectedLegalPaths: cleanList(parsed.detectedLegalPaths),

    factualThemes: cleanList(parsed.factualThemes),

    complexityLevel: normalizeComplexity(parsed.complexityLevel),

    completedForms: cleanList(parsed.completedForms),

    receivedForms: cleanList(parsed.receivedForms),

    requiredNextForms: cleanList(parsed.requiredNextForms),

    laterForms: cleanList(parsed.laterForms),

    notNeededNow: cleanList(parsed.notNeededNow),

    missingInformation: cleanList(parsed.missingInformation),

    evidenceMentioned: cleanList(parsed.evidenceMentioned),

    evidenceNeeded: cleanList(parsed.evidenceNeeded),

    legalIssues: cleanList(parsed.legalIssues),

    timelineAnalysis: cleanList(parsed.timelineAnalysis),

    proceduralStageReasoning: cleanList(
      parsed.proceduralStageReasoning
    ),

    risks: cleanList(parsed.risks),

    urgencyFlags: cleanList(parsed.urgencyFlags),

    emotionalTone: normalizeTone(parsed.emotionalTone),

    contradictions: cleanList(parsed.contradictions),

    evidenceStrengths: cleanList(parsed.evidenceStrengths),

    evidenceWeaknesses: cleanList(parsed.evidenceWeaknesses),

    missingEvidence: cleanList(parsed.missingEvidence),

    deadlineRisks: cleanList(parsed.deadlineRisks),

    serviceRisks: cleanList(parsed.serviceRisks),

    limitationRisks: cleanList(parsed.limitationRisks),

    opposingArguments: cleanList(parsed.opposingArguments),

    courtConcerns: cleanList(parsed.courtConcerns),

    recommendedQuestions: cleanList(parsed.recommendedQuestions),

    caseStrategy: cleanList(parsed.caseStrategy),

    casePackageItems: cleanList(parsed.casePackageItems),

    nextSteps: cleanList(parsed.nextSteps),
  };
}

export async function POST(req: Request) {
  try {
    const data = await req.json();

    if (!process.env.OPENAI_API_KEY) {
      return NextResponse.json(
        fallbackAnalysis("OpenAI API key is missing."),
        { status: 500 }
      );
    }

    const prompt = `
You are CourtSimplified’s procedural workflow and legal issue classification engine.

You are NOT a generic chatbot.
You are NOT a lawyer.
You do NOT give final legal advice.

Your role:
- classify the court path
- identify the procedural stage
- identify legal paths
- identify evidence gaps
- identify procedural risks
- identify ONLY the next likely procedural forms
- separate completed forms from future forms
- explain next procedural steps clearly

IMPORTANT:
- NEVER invent facts
- NEVER promise outcomes
- NEVER say someone will win
- NEVER recommend forms already completed
- NEVER recommend premature forms
- Use practical Ontario procedural reasoning
- Use supportive tone when users seem overwhelmed

VERY IMPORTANT:
requiredNextForms must contain ONLY likely NEXT procedural forms.

Do NOT flood the user with every possible form.

Return STRICT JSON ONLY.

INTAKE:
${JSON.stringify(data, null, 2)}
`;

    const response = await fetch(
      "https://api.openai.com/v1/chat/completions",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
        },
        body: JSON.stringify({
          model: "gpt-4o",
          messages: [{ role: "user", content: prompt }],
          temperature: 0.15,
          response_format: { type: "json_object" },
        }),
      }
    );

    const result = await response.json();

    if (!response.ok) {
      return NextResponse.json(
        fallbackAnalysis(
          "OpenAI error: " +
            (result?.error?.message || "Unknown error")
        ),
        { status: response.status }
      );
    }

    const rawContent =
      result?.choices?.[0]?.message?.content;

    if (!rawContent) {
      return NextResponse.json(
        fallbackAnalysis("No analysis generated.")
      );
    }

    let parsed: Partial<CourtSimplifiedAnalysis>;

    try {
      parsed = JSON.parse(rawContent);
    } catch {
      return NextResponse.json(
        fallbackAnalysis("AI returned invalid JSON.")
      );
    }

    const analysis = sanitizeAnalysis(parsed);

    return NextResponse.json({
      ...analysis,
      analysis,
      sourceRoute: "case-summary",
      sanitized: true,
    });
  } catch (err) {
    console.error(
      "CourtSimplified analysis route error:",
      err
    );

    return NextResponse.json(
      fallbackAnalysis("Server error."),
      { status: 500 }
    );
  }
}