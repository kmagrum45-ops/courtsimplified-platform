# CourtSimplified Live Flow Audit

## Rule

No new feature coding until the live workflow is mapped and verified.

This file tracks which pages, routes, engines, and storage paths actually control the user experience.

---

## Required Source-of-Truth Path

All live case-building flows must move toward this path:

```txt
User Intake
→ CourtSimplifiedBrain
→ BrainMigrationLayer
→ MasterCaseSchema
→ Supabase cases.master_result + localStorage fallback
→ Dashboard / Evidence / Forms / Documents / Packages